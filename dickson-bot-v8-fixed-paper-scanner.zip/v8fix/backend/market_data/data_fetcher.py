"""Twelve Data historical candle fetcher for the V8 paper/research terminal.

This module only retrieves market data. It does not place or manage live orders.
"""
from __future__ import annotations

import os
from typing import Any

import httpx

BASE_URL = "https://api.twelvedata.com/time_series"

SYMBOL_MAP = {
    "XAUUSD": "XAU/USD",
    "XAU/USD": "XAU/USD",
    "XAGUSD": "XAG/USD",
    "XAG/USD": "XAG/USD",
    "EURUSD": "EUR/USD",
    "EUR/USD": "EUR/USD",
    "GBPUSD": "GBP/USD",
    "GBP/USD": "GBP/USD",
    "BTCUSD": "BTC/USD",
    "BTC/USD": "BTC/USD",
}

INTERVAL_MAP = {
    "1m": "1min",
    "15m": "15min",
    "1h": "1h",
    "4h": "4h",
    "1d": "1day",
}


class TwelveDataError(RuntimeError):
    def __init__(self, message: str, *, code: int | None = None, http_status: int | None = None):
        super().__init__(message)
        self.code = code
        self.http_status = http_status


def _api_key() -> str:
    return os.getenv("TWELVE_DATA_API_KEY", "").strip()


def _normalise_symbol(symbol: str) -> str:
    return SYMBOL_MAP.get(symbol.upper(), symbol.upper())


def _normalise_interval(timeframe: str) -> str:
    try:
        return INTERVAL_MAP[timeframe.lower()]
    except KeyError as exc:
        raise TwelveDataError(f"Unsupported V8 timeframe: {timeframe}") from exc


def parse_response(payload: dict[str, Any], *, http_status: int = 200) -> list[dict[str, float]]:
    """Convert Twelve Data JSON into the V8 candle format."""
    status = payload.get("status")
    if http_status >= 400 or status == "error" or "code" in payload:
        code = payload.get("code")
        message = payload.get("message") or f"Twelve Data HTTP {http_status}"
        raise TwelveDataError(str(message), code=code, http_status=http_status)

    values = payload.get("values")
    if not isinstance(values, list):
        raise TwelveDataError("Twelve Data response did not contain a values array", http_status=http_status)

    candles: list[dict[str, float]] = []
    for row in values:
        try:
            # Twelve Data timestamps are exchange/UTC-labelled strings depending on asset.
            # Store the parsed epoch in UTC where possible.
            import datetime as dt
            stamp = str(row["datetime"])
            parsed = dt.datetime.fromisoformat(stamp.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=dt.timezone.utc)
            timestamp = parsed.timestamp()
            candles.append({
                "timestamp": float(timestamp),
                "open": float(row["open"]),
                "high": float(row["high"]),
                "low": float(row["low"]),
                "close": float(row["close"]),
            })
        except (KeyError, TypeError, ValueError, OverflowError):
            continue

    candles.sort(key=lambda x: x["timestamp"])
    return candles


async def fetch_candles(symbol: str = "XAUUSD", timeframe: str = "15m", limit: int = 300) -> list[dict[str, float]]:
    """Fetch historical candles from Twelve Data for paper/research analysis."""
    key = _api_key()
    if not key:
        raise TwelveDataError("TWELVE_DATA_API_KEY is not configured")

    interval = _normalise_interval(timeframe)
    td_symbol = _normalise_symbol(symbol)
    outputsize = max(1, min(int(limit), 5000))

    params = {
        "symbol": td_symbol,
        "interval": interval,
        "outputsize": outputsize,
        "apikey": key,
        "format": "JSON",
        "order": "ASC",
    }

    try:
        async with httpx.AsyncClient(timeout=15, headers={"User-Agent": "DicksonBotV8/8.0"}) as client:
            response = await client.get(BASE_URL, params=params)
            try:
                payload = response.json()
            except ValueError as exc:
                raise TwelveDataError(
                    f"Twelve Data returned non-JSON HTTP {response.status_code}",
                    http_status=response.status_code,
                ) from exc
    except httpx.HTTPError as exc:
        raise TwelveDataError(f"Network error contacting Twelve Data: {exc}") from exc

    return parse_response(payload, http_status=response.status_code)[-outputsize:]
