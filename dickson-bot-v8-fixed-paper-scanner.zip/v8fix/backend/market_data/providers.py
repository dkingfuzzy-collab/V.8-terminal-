import os, json, time
from backend.market_data.data_fetcher import fetch_candles as twelve_fetch_candles
import httpx
import websockets

YAHOO = "https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
COINBASE = "https://api.exchange.coinbase.com/products/BTC-USD/candles"

SYMBOL_MAP = {
    "BTCUSD": "BTC-USD", "BTC/USDT": "BTC-USD",
    "EURUSD": "EURUSD=X", "GBPUSD": "GBPUSD=X",
    "XAUUSD": "XAUUSD=X", "XAGUSD": "XAGUSD=X",
}
INTERVALS = {"1m":"1m", "15m":"15m", "1h":"1h", "4h":"1h", "1d":"1d"}

async def yahoo_history(symbol:str,timeframe:str,limit:int=300):
    ticker=SYMBOL_MAP.get(symbol,symbol)
    interval=INTERVALS.get(timeframe,timeframe)
    period1=int(time.time()-90*86400) if timeframe in {"15m","1h","4h"} else int(time.time()-730*86400)
    if timeframe=="1m": period1=int(time.time()-7*86400)
    params={"period1":period1,"period2":int(time.time()),"interval":interval,"events":"history","includeAdjustedClose":"true"}
    async with httpx.AsyncClient(timeout=12,headers={"User-Agent":"DicksonBot/8.1"}) as client:
        r=await client.get(YAHOO.format(symbol=ticker),params=params); r.raise_for_status(); j=r.json()
    result=(j.get("chart") or {}).get("result") or []
    if not result: raise RuntimeError("Yahoo returned no chart data")
    q=(result[0].get("indicators") or {}).get("quote") or []
    if not q: raise RuntimeError("Yahoo returned no quote data")
    ts=result[0].get("timestamp") or []
    rows=[]
    for i,t in enumerate(ts):
        try:
            o,h,l,c=[q[0][k][i] for k in ("open","high","low","close")]
            if None not in (o,h,l,c): rows.append({"timestamp":float(t),"open":float(o),"high":float(h),"low":float(l),"close":float(c)})
        except (IndexError,TypeError,KeyError): pass
    if timeframe=="4h": rows=_resample(rows,4*3600)
    return rows[-limit:]

async def coinbase_history(symbol:str,timeframe:str,limit:int=300):
    gran={"1m":60,"15m":900,"1h":3600,"4h":3600,"1d":86400}.get(timeframe,900)
    end=time.time(); start=end-gran*min(limit,300)
    async with httpx.AsyncClient(timeout=12,headers={"User-Agent":"DicksonBot/8.1"}) as client:
        r=await client.get(COINBASE,params={"granularity":gran,"start":time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(start)),"end":time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(end))})
        r.raise_for_status(); rows=r.json()
    out=[{"timestamp":float(x[0]),"open":float(x[3]),"high":float(x[2]),"low":float(x[1]),"close":float(x[4])} for x in rows]
    out.sort(key=lambda x:x["timestamp"])
    if timeframe=="4h": out=_resample(out,4*3600)
    return out[-limit:]

def _resample(rows,seconds):
    if not rows:return []
    out=[]; current=None
    for r in rows:
        bucket=int(r["timestamp"]//seconds)*seconds
        if current is None or current["timestamp"]!=bucket:
            if current: out.append(current)
            current={"timestamp":bucket,"open":r["open"],"high":r["high"],"low":r["low"],"close":r["close"]}
        else:
            current["high"]=max(current["high"],r["high"]); current["low"]=min(current["low"],r["low"]); current["close"]=r["close"]
    if current:out.append(current)
    return out

async def twelve_history(symbol:str,timeframe:str,limit:int=300):
    return await twelve_fetch_candles(symbol, timeframe, limit)

async def history(symbol,timeframe,limit=300):
    errors=[]; attempts=[]
    providers=[]
    # Twelve Data is the primary source for all supported scanner assets.
    if os.getenv("TWELVE_DATA_API_KEY", "").strip():
        providers.append(("twelve_data",twelve_history))
    else:
        errors.append("twelve_data: not configured (TWELVE_DATA_API_KEY missing)")
    # BTC keeps a public fallback because Coinbase worked in the user's deployment.
    if symbol=="BTCUSD":
        providers.extend([("coinbase",coinbase_history), ("yahoo",yahoo_history)])
    else:
        # Yahoo is diagnostic fallback only; it is not preferred for metals/FX.
        providers.append(("yahoo",yahoo_history))
    for name,fn in providers:
        try:
            rows=await fn(symbol,timeframe,limit)
            if len(rows)>=10:
                attempts.append(f"{name}: OK ({len(rows)} candles)")
                return rows,name,None,{"attempts":attempts+errors,"selected":name}
            msg=f"{name}: only {len(rows)} candles"; attempts.append(msg); errors.append(msg)
        except Exception as e:
            msg=f"{name}: {type(e).__name__}: {e}"; attempts.append(msg)
    all_errors=attempts + [e for e in errors if e not in attempts]
    return [],"none","; ".join(all_errors) if all_errors else "No provider configured",{"attempts":all_errors,"selected":"none"}

async def public_crypto_stream():
    uri="wss://ws-feed.exchange.coinbase.com"
    async with websockets.connect(uri,ping_interval=20,ping_timeout=20) as ws:
        await ws.send(json.dumps({"type":"subscribe","product_ids":["BTC-USD"],"channels":["ticker"]}))
        async for raw in ws:
            msg=json.loads(raw)
            if msg.get("type")=="ticker" and msg.get("price"):
                yield {"provider":"coinbase","symbol":"BTCUSD","price":float(msg["price"]),"timestamp":time.time()}
