import time
from backend.market_data.providers import history
from backend.market_data.aggregator import CandleAggregator

# Avoid hammering the provider while keeping the entry timeframe reasonably fresh.
MAX_AGE = {"15m": 75, "1h": 300, "4h": 900, "1d": 3600, "1m": 45}

class MarketDataService:
    def __init__(self, aggregator):
        self.aggregator = aggregator
        self.cache = {}
        self.diagnostics = {}

    async def bootstrap(self, symbol, timeframe, limit=300, force=False):
        key = (symbol, timeframe)
        now = time.time()
        cached = self.cache.get(key)
        max_age = MAX_AGE.get(timeframe, 300)
        if not force and cached and cached.get("candles") and (now - cached.get("updated_at", 0) < max_age):
            return cached
        result = await history(symbol, timeframe, limit)
        rows, provider, error, provider_diag = result
        item = {
            "symbol": symbol, "timeframe": timeframe, "candles": rows,
            "provider": provider if rows else "none",
            "mode": "market_data" if rows else "unavailable",
            "error": None if rows else error,
            "updated_at": now, "candle_count": len(rows),
            "provider_diagnostics": provider_diag,
        }
        if rows:
            self.aggregator.seed(symbol, timeframe, rows)
        self.cache[key] = item
        self.diagnostics[f"{symbol}:{timeframe}"] = item
        return item

    def status(self):
        return {"sources": self.diagnostics, "cached_series": len(self.cache), "cache_max_age_seconds": MAX_AGE}
