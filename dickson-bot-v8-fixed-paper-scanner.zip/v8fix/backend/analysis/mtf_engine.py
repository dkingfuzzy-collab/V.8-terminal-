from statistics import mean

TF_ORDER=["1d","4h","1h","15m"]

def _state_details(bars, lookback=30):
    if len(bars)<10: return {"state":"INSUFFICIENT","reason":"Insufficient candles","higher_highs":False,"higher_lows":False,"lower_highs":False,"lower_lows":False}
    x=bars[-min(lookback,len(bars)):]; mid=max(2,len(x)//2); first=x[:mid]; second=x[mid:]
    hi0=max(b["high"] for b in first); hi1=max(b["high"] for b in second); lo0=min(b["low"] for b in first); lo1=min(b["low"] for b in second)
    hh=hi1>hi0; hl=lo1>=lo0; lh=hi1<hi0; ll=lo1<=lo0
    if hh and hl: state="BULLISH"; reason=f"HH/HL: high {hi1:.5g}>{hi0:.5g}, low {lo1:.5g}>={lo0:.5g}"
    elif lh and ll: state="BEARISH"; reason=f"LH/LL: high {hi1:.5g}<{hi0:.5g}, low {lo1:.5g}<={lo0:.5g}"
    else: state="NEUTRAL"; reason="Mixed/ranging structure: HH/HL and LH/LL are not aligned"
    return {"state":state,"reason":reason,"higher_highs":hh,"higher_lows":hl,"lower_highs":lh,"lower_lows":ll}

def _sweep(bars,lookback=6):
    if len(bars)<lookback+1:return {"bullish":False,"bearish":False,"reason":"Insufficient candles for sweep"}
    x=bars[-1]; p=bars[-lookback-1:-1]; ph=max(v["high"] for v in p); pl=min(v["low"] for v in p)
    bull=x["low"]<pl and x["close"]>pl; bear=x["high"]>ph and x["close"]<ph
    return {"bullish":bull,"bearish":bear,"prior_high":ph,"prior_low":pl,"reason":"Bullish sweep/reclaim" if bull else "Bearish sweep/rejection" if bear else "No sweep on latest candle"}

def _displacement(bars,factor=1.3):
    if len(bars)<10:return {"bullish":False,"bearish":False,"reason":"Insufficient candles for displacement"}
    x=bars[-1]; avg=mean(v["high"]-v["low"] for v in bars[-10:-1]); body=abs(x["close"]-x["open"]); strong=avg>0 and body>=factor*avg
    bull=strong and x["close"]>x["open"]; bear=strong and x["close"]<x["open"]
    return {"bullish":bull,"bearish":bear,"body":body,"avg_range":avg,"reason":"Bullish displacement" if bull else "Bearish displacement" if bear else "No displacement"}

def _fvg(bars):
    if len(bars)<3:return {"bullish":False,"bearish":False,"reason":"Insufficient candles for FVG"}
    # Scan recent completed triples; report the most recent imbalance.
    for i in range(len(bars)-1,1,-1):
        a,b,c=bars[i-2],bars[i-1],bars[i]
        if c["low"]>a["high"]: return {"bullish":True,"bearish":False,"gap_low":a["high"],"gap_high":c["low"],"index":i,"reason":"Recent bullish three-candle FVG"}
        if c["high"]<a["low"]: return {"bullish":False,"bearish":True,"gap_low":c["high"],"gap_high":a["low"],"index":i,"reason":"Recent bearish three-candle FVG"}
    return {"bullish":False,"bearish":False,"reason":"No recent qualifying FVG"}

def analyze_timeframe(bars):
    s=_state_details(bars); return {"state":s["state"],"reason":s["reason"],"structure":s,"sweep":_sweep(bars),"displacement":_displacement(bars),"fvg":_fvg(bars),"candle_count":len(bars)}

def analyze_mtf(symbol,candles):
    a={tf:analyze_timeframe(candles.get(tf,[])) for tf in TF_ORDER}
    bull_context=a["1d"]["state"]=="BULLISH" and a["4h"]["state"] in {"BULLISH","NEUTRAL"}
    bear_context=a["1d"]["state"]=="BEARISH" and a["4h"]["state"] in {"BEARISH","NEUTRAL"}
    br=[]; sr=[]
    for tf in TF_ORDER:
        if a[tf]["sweep"].get("bullish"): br.append(f"{tf} sell-side sweep/reclaim")
        if a[tf]["displacement"].get("bullish"): br.append(f"{tf} bullish displacement")
        if a[tf]["fvg"].get("bullish"): br.append(f"{tf} bullish FVG")
        if a[tf]["sweep"].get("bearish"): sr.append(f"{tf} buy-side sweep/rejection")
        if a[tf]["displacement"].get("bearish"): sr.append(f"{tf} bearish displacement")
        if a[tf]["fvg"].get("bearish"): sr.append(f"{tf} bearish FVG")
    bull=bool(bull_context and a["15m"]["state"] in {"BULLISH","NEUTRAL"} and br)
    bear=bool(bear_context and a["15m"]["state"] in {"BEARISH","NEUTRAL"} and sr)
    score_b=min(10,2*int(a["1d"]["state"]=="BULLISH")+2*int(a["4h"]["state"]=="BULLISH")+int(a["1h"]["state"]=="BULLISH")+2*int(a["15m"]["sweep"].get("bullish"))+2*int(a["15m"]["displacement"].get("bullish"))+int(a["15m"]["fvg"].get("bullish")))
    score_s=min(10,2*int(a["1d"]["state"]=="BEARISH")+2*int(a["4h"]["state"]=="BEARISH")+int(a["1h"]["state"]=="BEARISH")+2*int(a["15m"]["sweep"].get("bearish"))+2*int(a["15m"]["displacement"].get("bearish"))+int(a["15m"]["fvg"].get("bearish")))
    if bull and score_b>=5 and score_b>score_s: signal="BUY_PAPER"
    elif bear and score_s>=5 and score_s>score_b: signal="SELL_PAPER"
    else: signal="NO_SETUP"
    score=score_b if signal=="BUY_PAPER" else score_s if signal=="SELL_PAPER" else max(score_b,score_s)
    blockers=[]
    if signal=="NO_SETUP":
        if not bull_context and not bear_context: blockers.append("Daily/4H context is not aligned")
        if not br and not sr: blockers.append("No recent sweep, displacement, or FVG evidence")
        if br and not sr and score_b<5: blockers.append(f"Bullish MTF evidence score is {score_b}/10")
        if sr and not br and score_s<5: blockers.append(f"Bearish MTF evidence score is {score_s}/10")
        if br and sr: blockers.append("Bullish and bearish evidence is mixed")
        if a["15m"]["state"]=="INSUFFICIENT": blockers.append("15M has insufficient candles")
    return {"symbol":symbol,"mode":"paper_only","timeframes":a,"signal":signal,"confluence_score":score,"bullish_reasons":br,"bearish_reasons":sr,"blockers":blockers}
