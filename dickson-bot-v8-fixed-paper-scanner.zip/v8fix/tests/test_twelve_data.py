from backend.market_data.data_fetcher import TwelveDataError, parse_response


def test_twelve_data_parser():
    payload = {
        "status": "ok",
        "values": [
            {"datetime": "2026-10-01 10:00:00", "open": "100", "high": "105", "low": "99", "close": "103"},
            {"datetime": "2026-10-01 10:15:00", "open": "103", "high": "106", "low": "102", "close": "105"},
        ],
    }
    rows = parse_response(payload)
    assert len(rows) == 2
    assert rows[0]["open"] == 100.0
    assert rows[1]["close"] == 105.0
    assert rows[0]["timestamp"] < rows[1]["timestamp"]


def test_twelve_data_error_is_preserved():
    try:
        parse_response({"status": "error", "code": 401, "message": "Invalid API key"}, http_status=401)
    except TwelveDataError as exc:
        assert exc.code == 401
        assert "Invalid API key" in str(exc)
    else:
        raise AssertionError("Expected TwelveDataError")
