from statistics import mean

TF_ORDER = ["1d", "4h", "1h", "15m"]

def _state_details(bars, lookback=30):
    if len(bars) < 10:
        return {"state":"INSUFFICIENT", "reason":"Insufficient candles", "higher_highs":False, "higher_lows":False, "lower_highs":False, "lower_lows":False}
    x=bars[-min(lookback,len(bars)):]; mid=max(1,len(x)//2)
    first=x[:mid]; second=x[mid:]
    hi0=max(b["high"] for b in first); hi1=max(b["high"] for b in second)
    lo0=min(b["low"] for b in first); lo1=min(b["low"] for b in second)
    hh=hi1>hi0; hl=lo1>=lo0; lh=hi1<hi0; ll=lo1<=lo0
    if hh and hl:
        state="BULLISH"; reason=f"Higher high ({hi1:.5g} > {hi0:.5g}) and higher/equal low ({lo1:.5g} >= {lo0:.5g})"
    elif lh and ll:
        state="BEARISH"; reason=f"Lower high ({hi1:.5g} < {hi0:.5g}) and lower/equal low ({lo1:.5g} <= {lo0:.5g})"
    else:
        state="NEUTRAL"; reason="Range/structure is mixed; both sides are not aligned"
    return {"state":state,"reason":reason,"higher_highs":hh,"higher_lows":hl,"lower_highs":lh,"lower_lows":ll}

def _state(bars, lookback=30):
    return _state_details(bars, lookback)["state"]

def _sweep(bars, lookback=6):
    if len(bars)<lookback+1: return {"bullish":False,"bearish":False}
    x=bars[-1]; p=bars[-lookback-1:-1]; ph=max(v["high"] for v in p); pl=min(v["low"] for v in p)
    return {"bullish":x["low"]<pl and x["close"]>pl,"bearish":x["high"]>ph and x["close"]<ph}

def _displacement(bars, factor=1.3):
    if len(bars)<10: return {"bullish":False,"bearish":False}
    x=bars[-1]; avg=mean(v["high"]-v["low"] for v in bars[-10:-1]); body=abs(x["close"]-x["open"]); strong=avg>0 and body>=factor*avg
    return {"bullish":strong and x["close"]>x["open"],"bearish":strong and x["close"]<x["open"]}

def _fvg(bars):
    if len(bars)<3: return {"bullish":False,"bearish":False}
    a,c=bars[-3],bars[-1]
    return {"bullish":c["low"]>a["high"],"bearish":c["high"]<a["low"]}

def analyze_timeframe(bars):
    state=_state_details(bars)
    return {"state":state["state"],"reason":state["reason"],"structure":state,"sweep":_sweep(bars),"displacement":_displacement(bars),"fvg":_fvg(bars),"candle_count":len(bars)}

def analyze_mtf(symbol, candles):
    a={tf:analyze_timeframe(candles.get(tf,[])) for tf in TF_ORDER}
    bull_context=a["1d"]["state"]=="BULLISH" and a["4h"]["state"] in {"BULLISH","NEUTRAL"}
    bear_context=a["1d"]["state"]=="BEARISH" and a["4h"]["state"] in {"BEARISH","NEUTRAL"}
    bull_reasons=[]; bear_reasons=[]
    for tf in TF_ORDER:
        if a[tf]["sweep"]["bullish"]: bull_reasons.append(f"{tf} liquidity sweep")
        if a[tf]["displacement"]["bullish"]: bull_reasons.append(f"{tf} bullish displacement")
        if a[tf]["fvg"]["bullish"]: bull_reasons.append(f"{tf} bullish FVG")
        if a[tf]["sweep"]["bearish"]: bear_reasons.append(f"{tf} liquidity sweep")
        if a[tf]["displacement"]["bearish"]: bear_reasons.append(f"{tf} bearish displacement")
        if a[tf]["fvg"]["bearish"]: bear_reasons.append(f"{tf} bearish FVG")
    bull=a["15m"]["state"] in {"BULLISH","NEUTRAL"} and bull_context and bool(bull_reasons)
    bear=a["15m"]["state"] in {"BEARISH","NEUTRAL"} and bear_context and bool(bear_reasons)
    score_b=min(10,2*int(a["1d"]["state"]=="BULLISH")+2*int(a["4h"]["state"]=="BULLISH")+int(a["1h"]["state"]=="BULLISH")+2*int(a["15m"]["sweep"]["bullish"])+2*int(a["15m"]["displacement"]["bullish"])+int(a["15m"]["fvg"]["bullish"]))
    score_s=min(10,2*int(a["1d"]["state"]=="BEARISH")+2*int(a["4h"]["state"]=="BEARISH")+int(a["1h"]["state"]=="BEARISH")+2*int(a["15m"]["sweep"]["bearish"])+2*int(a["15m"]["displacement"]["bearish"])+int(a["15m"]["fvg"]["bearish"]))
    if bull and score_b>=5 and score_b>=score_s: signal="BUY_PAPER"
    elif bear and score_s>=5: signal="SELL_PAPER"
    else: signal="NO_SETUP"
    score=score_b if signal=="BUY_PAPER" else score_s if signal=="SELL_PAPER" else max(score_b,score_s)
    blockers=[]
    if signal=="NO_SETUP":
        if not bull_context and not bear_context: blockers.append("Daily/4H context is not aligned")
        if not bull_reasons and not bear_reasons: blockers.append("No sweep, displacement, or FVG evidence across the four timeframes")
        if bull_reasons and not bear_reasons and score_b<5: blockers.append(f"Bullish MTF evidence score is only {score_b}/10")
        if bear_reasons and not bull_reasons and score_s<5: blockers.append(f"Bearish MTF evidence score is only {score_s}/10")
        if bull_reasons and bear_reasons: blockers.append("Bullish and bearish evidence is mixed")
    return {"symbol":symbol,"mode":"paper_only","timeframes":a,"signal":signal,"confluence_score":score,"bullish_reasons":bull_reasons,"bearish_reasons":bear_reasons,"blockers":blockers}
