"""Single-source market data provider for the V8 paper/research terminal.

All scanner candle data comes from Twelve Data. There are deliberately no
Yahoo/Coinbase fallbacks so a missing/invalid feed is never disguised as a
successful analysis from a different price source.
"""
from __future__ import annotations

import os
from backend.market_data.data_fetcher import fetch_candles as twelve_fetch_candles

SUPPORTED_DEFAULT_SYMBOLS = ["XAUUSD", "XAGUSD", "BTCUSD", "EURUSD", "GBPUSD"]
SUPPORTED_TIMEFRAMES = ["1m", "15m", "1h", "4h", "1d"]


async def twelve_history(symbol: str, timeframe: str, limit: int = 300):
    return await twelve_fetch_candles(symbol, timeframe, limit)


async def history(symbol: str, timeframe: str, limit: int = 300):
    """Fetch candles from Twelve Data only.

    Returns rows, provider, error, diagnostics. The diagnostics always include
    whether the API key is configured and the exact Twelve Data error when a
    request fails.
    """
    configured = bool(os.getenv("TWELVE_DATA_API_KEY", "").strip())
    attempts = []
    if not configured:
        msg = "TWELVE_DATA_API_KEY is not configured"
        attempts.append(f"twelve_data: ERROR: {msg}")
        return [], "none", msg, {
            "provider_policy": "twelve_data_only",
            "api_key_configured": False,
            "attempts": attempts,
            "selected": "none",
        }

    try:
        rows = await twelve_history(symbol, timeframe, limit)
        if len(rows) < 10:
            msg = f"Twelve Data returned only {len(rows)} candles; at least 10 are required"
            attempts.append(f"twelve_data: ERROR: {msg}")
            return [], "none", msg, {
                "provider_policy": "twelve_data_only",
                "api_key_configured": True,
                "attempts": attempts,
                "selected": "none",
            }
        attempts.append(f"twelve_data: OK ({len(rows)} candles)")
        return rows, "twelve_data", None, {
            "provider_policy": "twelve_data_only",
            "api_key_configured": True,
            "attempts": attempts,
            "selected": "twelve_data",
        }
    except Exception as exc:
        msg = f"Twelve Data: {type(exc).__name__}: {exc}"
        attempts.append(msg)
        return [], "none", msg, {
            "provider_policy": "twelve_data_only",
            "api_key_configured": True,
            "attempts": attempts,
            "selected": "none",
        }


async def test_provider(symbol: str, timeframe: str = "15m", limit: int = 20):
    """Small live provider contract test used by Diagnostics."""
    rows, provider, error, diag = await history(symbol, timeframe, limit)
    return {
        "symbol": symbol,
        "timeframe": timeframe,
        "provider": provider,
        "ok": bool(rows and provider == "twelve_data"),
        "candles": len(rows),
        "error": error,
        "diagnostics": diag,
    }
