from backend.market_data.data_fetcher import TwelveDataError, parse_response


def test_twelve_data_parser():
    payload = {
        "status": "ok",
        "values": [
            {"datetime": "2026-10-01 10:00:00", "open": "100", "high": "105", "low": "99", "close": "103"},
            {"datetime": "2026-10-01 10:15:00", "open": "103", "high": "106", "low": "102", "close": "105"},
        ],
    }
    rows = parse_response(payload)
    assert len(rows) == 2
    assert rows[0]["open"] == 100.0
    assert rows[1]["close"] == 105.0
    assert rows[0]["timestamp"] < rows[1]["timestamp"]


def test_twelve_data_error_is_preserved():
    try:
        parse_response({"status": "error", "code": 401, "message": "Invalid API key"}, http_status=401)
    except TwelveDataError as exc:
        assert exc.code == 401
        assert "Invalid API key" in str(exc)
    else:
        raise AssertionError("Expected TwelveDataError")

import os
import asyncio
from backend.market_data import providers


def test_provider_policy_is_twelve_data_only():
    assert providers.SUPPORTED_DEFAULT_SYMBOLS == ["XAUUSD", "XAGUSD", "BTCUSD", "EURUSD", "GBPUSD"]
    assert providers.SUPPORTED_TIMEFRAMES == ["1m", "15m", "1h", "4h", "1d"]


def test_missing_key_fails_explicitly(monkeypatch):
    monkeypatch.delenv("TWELVE_DATA_API_KEY", raising=False)
    result = asyncio.run(providers.test_provider("XAUUSD", "15m", 20))
    assert result["ok"] is False
    assert "TWELVE_DATA_API_KEY" in result["error"]
